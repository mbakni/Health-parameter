package health.person.parameter;

public class healthParameter {
	private int pulseRate ;
	private int breathingRate;
	private int temperature;
	private String bdyPosition;
	private BloodPressure bldPressure;
	
	
	public healthParameter (int value1, int value2, int value3, String value4, int value5, int value6) {
		pulseRate = value1;
		breathingRate = value2;
		temperature = value3;
		bdyPosition = value4;
		bldPressure.setDiastolic(value5);
		bldPressure.setSystolic(value6);
	                             } 
	

	public int getPulseRate() {
		return pulseRate;
							   }

	public void setPulseRate(int pulseRate) {
		this.pulseRate = pulseRate;
	                                        }

	public int getBreathingRate() {
		return breathingRate;
	                               }               

	public void setBreathingRate(int breathingRate) {
		this.breathingRate = breathingRate;
	                                                } 

	public int getTemperature() {
		return temperature;
	                            }

	public void setTemperature(int temperature) {
		this.temperature = temperature;
	                                             }

	public BloodPressure getBldPressure() {
		return bldPressure;
	                                      }

	public void setBldPressure(BloodPressure bldPressure) {
		this.bldPressure = bldPressure;
	                                                       }
	
	public String toString() {
		String st;
		st = " pulseRate: " + Integer.toString(pulseRate) + ", breathingRate is: "+ Integer.toString(breathingRate) + ", temperature is: "+ Integer.toString(temperature) +", bodyPosition is: "+ bdyPosition + bldPressure.toString() ;
		return st;
	} 
	
}
